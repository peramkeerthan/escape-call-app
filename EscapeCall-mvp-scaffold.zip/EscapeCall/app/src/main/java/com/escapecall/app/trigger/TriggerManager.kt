package com.escapecall.app.trigger

import android.util.Log
import com.escapecall.app.domain.ActionEngine

/**
 * The reusable core described in Section 22: TriggerManager knows nothing about calls.
 * It just says "the configured trigger fired" and hands off to ActionEngine, which today
 * only has a Fake Call action but could route to Real Call / Notification / Alarm later
 * without TriggerManager or the detectors changing at all.
 */
object TriggerManager {

    private var detector: TriggerDetector? = null
    private var enabled: Boolean = false
    private var lastActivationTime: Long = 0L
    private var cooldownMillis: Long = 3000L
    private var actionEngine: ActionEngine? = null

    fun configure(config: TriggerConfig, engine: ActionEngine) {
        detector = when (config) {
            is TriggerConfig.ButtonSequence -> {
                cooldownMillis = config.cooldownMillis
                ButtonSequenceDetector(config)
            }
            is TriggerConfig.Gesture, is TriggerConfig.ScreenTap ->
                throw UnsupportedOperationException("Trigger type not implemented in MVP: ${config.id}")
        }
        actionEngine = engine
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        detector?.reset()
    }

    fun isEnabled(): Boolean = enabled

    /** Called from TriggerAccessibilityService for every raw key event. */
    fun onKeyEvent(keyCode: Int, isDown: Boolean, eventTimeMillis: Long) {
        if (!enabled) return
        val d = detector ?: return

        if (eventTimeMillis - lastActivationTime < cooldownMillis) {
            return // Section 9: cooldown period after activation
        }

        val fired = d.onKeyEvent(keyCode, isDown, eventTimeMillis)
        if (fired) {
            lastActivationTime = eventTimeMillis
            Log.i("TriggerManager", "Trigger fired")
            actionEngine?.onTriggerFired()
        }
    }

    fun testTriggerNow() {
        // "Quick test button" (Section 10, Home screen) bypasses detection entirely.
        actionEngine?.onTriggerFired()
    }
}
