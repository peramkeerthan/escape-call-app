package com.escapecall.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.escapecall.app.data.ProfileRepository
import com.escapecall.app.trigger.ButtonEvent
import com.escapecall.app.trigger.TriggerConfig
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

/**
 * MVP scope (Section 16): only ButtonSequence is configurable here. The screen still shows
 * Gesture/Screen Tap as disabled options so the information architecture from Section 4
 * doesn't need to be redesigned when they ship in v2.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TriggerSetupScreen(
    repository: ProfileRepository,
    profileId: Long,
    onDone: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var sequence by remember { mutableStateOf(listOf(ButtonEvent.VOLUME_DOWN, ButtonEvent.VOLUME_UP, ButtonEvent.VOLUME_DOWN)) }
    var maxInterval by remember { mutableStateOf(2.5f) }
    var cooldown by remember { mutableStateOf(3f) }

    LaunchedEffect(profileId) {
        repository.getProfile(profileId)?.let { p ->
            val config = Json.decodeFromString<TriggerConfig.ButtonSequence>(p.triggerConfigJson)
            sequence = config.sequence
            maxInterval = config.maxIntervalMillis / 1000f
            cooldown = config.cooldownMillis / 1000f
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trigger Setup") },
                navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()) {

            Text("Trigger type", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = true, onClick = {}, label = { Text("Button sequence") })
                FilterChip(selected = false, onClick = {}, label = { Text("Gesture (soon)") }, enabled = false)
                FilterChip(selected = false, onClick = {}, label = { Text("Screen tap (soon)") }, enabled = false)
            }

            Spacer(Modifier.height(24.dp))
            Text("Sequence", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                sequence.forEachIndexed { index, event ->
                    AssistChip(
                        onClick = { sequence = sequence.toMutableList().also { it.removeAt(index) } },
                        label = { Text(event.shortLabel()) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { sequence = sequence + ButtonEvent.VOLUME_UP }) { Text("+ Vol Up") }
                OutlinedButton(onClick = { sequence = sequence + ButtonEvent.VOLUME_DOWN }) { Text("+ Vol Down") }
                TextButton(onClick = { sequence = emptyList() }) { Text("Clear") }
            }

            Spacer(Modifier.height(24.dp))
            Text("Max time between presses: ${"%.1f".format(maxInterval)}s")
            Slider(value = maxInterval, onValueChange = { maxInterval = it }, valueRange = 0.5f..5f)

            Spacer(Modifier.height(12.dp))
            Text("Cooldown after activation: ${cooldown.toInt()}s")
            Slider(value = cooldown, onValueChange = { cooldown = it }, valueRange = 1f..10f)

            Spacer(Modifier.height(24.dp))
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = sequence.isNotEmpty(),
                onClick = { /* Hook into TriggerManager.testTriggerNow() for a dry run in the full impl */ }
            ) { Text("Test this trigger") }

            Spacer(Modifier.weight(1f))

            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = sequence.isNotEmpty(),
                onClick = {
                    scope.launch {
                        val profile = repository.getProfile(profileId) ?: return@launch
                        val config = TriggerConfig.ButtonSequence(
                            sequence = sequence,
                            maxIntervalMillis = (maxInterval * 1000).toLong(),
                            cooldownMillis = (cooldown * 1000).toLong()
                        )
                        repository.saveProfile(
                            profile.copy(triggerConfigJson = Json.encodeToString(TriggerConfig.ButtonSequence.serializer(), config))
                        )
                        onDone()
                    }
                }
            ) { Text("Save trigger") }
        }
    }
}

private fun ButtonEvent.shortLabel(): String = when (this) {
    ButtonEvent.VOLUME_UP -> "Vol Up"
    ButtonEvent.VOLUME_DOWN -> "Vol Down"
    ButtonEvent.VOLUME_UP_LONG -> "Vol Up (long)"
    ButtonEvent.VOLUME_DOWN_LONG -> "Vol Down (long)"
}
