package com.escapecall.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private data class PermissionInfo(val title: String, val why: String, val required: Boolean)

private val permissions = listOf(
    PermissionInfo(
        title = "Accessibility service (key event detection)",
        why = "Needed to detect your configured button sequence while the app is closed or the screen is locked. " +
            "This app only reads volume key presses through this service — it does not read screen content, " +
            "and it never blocks your normal volume control.",
        required = true
    ),
    PermissionInfo(
        title = "Notifications",
        why = "Used to show the incoming-call screen, including the countdown before it appears.",
        required = true
    ),
    PermissionInfo(
        title = "Full-screen intent",
        why = "Lets the fake call appear over the lock screen like a real call. On some devices/Android " +
            "versions this may be limited by the system; the notification's tap target still opens the call screen.",
        required = false
    ),
    PermissionInfo(
        title = "Battery optimization exemption",
        why = "Recommended (not required) so Android doesn't delay or kill the trigger-detection service " +
            "while the phone is idle.",
        required = false
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Permissions") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            Text(
                "This app avoids collecting contacts, call history, location, or photos beyond what " +
                    "you explicitly choose for a caller image. Everything stays on your device.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))

            permissions.forEach { p ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(p.title, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(4.dp))
                        Text(p.why, style = MaterialTheme.typography.bodySmall)
                        if (!p.required) {
                            Spacer(Modifier.height(4.dp))
                            Text("Optional", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            ) { Text("Open Accessibility settings") }

            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = android.net.Uri.fromParts("package", context.packageName, null)
                    })
                }
            ) { Text("Open app notification settings") }
        }
    }
}
