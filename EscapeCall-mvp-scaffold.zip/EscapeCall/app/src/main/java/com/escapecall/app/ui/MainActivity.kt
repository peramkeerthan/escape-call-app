package com.escapecall.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.escapecall.app.EscapeCallApp
import com.escapecall.app.ui.screens.*

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Profiles : Screen("profiles")
    object ProfileEdit : Screen("profile_edit/{profileId}") {
        fun route(profileId: Long) = "profile_edit/$profileId"
    }
    object TriggerSetup : Screen("trigger_setup/{profileId}") {
        fun route(profileId: Long) = "trigger_setup/$profileId"
    }
    object Permissions : Screen("permissions")
    object Settings : Screen("settings")
    object History : Screen("history")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as EscapeCallApp

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier) {
                    val navController = rememberNavController()
                    EscapeCallNavHost(navController, app)
                }
            }
        }
    }
}

@Composable
fun EscapeCallNavHost(navController: NavHostController, app: EscapeCallApp) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                repository = app.repository,
                onOpenProfiles = { navController.navigate(Screen.Profiles.route) },
                onOpenPermissions = { navController.navigate(Screen.Permissions.route) },
                onOpenSettings = { navController.navigate(Screen.Settings.route) },
                onOpenHistory = { navController.navigate(Screen.History.route) }
            )
        }
        composable(Screen.Profiles.route) {
            ProfileListScreen(
                repository = app.repository,
                onCreateProfile = { navController.navigate(Screen.ProfileEdit.route(0L)) },
                onEditProfile = { id -> navController.navigate(Screen.ProfileEdit.route(id)) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            route = Screen.ProfileEdit.route,
            arguments = listOf(navArgument("profileId") { type = NavType.LongType })
        ) { backStackEntry ->
            val profileId = backStackEntry.arguments?.getLong("profileId") ?: 0L
            ProfileEditScreen(
                repository = app.repository,
                profileId = profileId,
                onOpenTriggerSetup = { navController.navigate(Screen.TriggerSetup.route(profileId)) },
                onDone = { navController.popBackStack(Screen.Profiles.route, inclusive = false) }
            )
        }
        composable(
            route = Screen.TriggerSetup.route,
            arguments = listOf(navArgument("profileId") { type = NavType.LongType })
        ) { backStackEntry ->
            val profileId = backStackEntry.arguments?.getLong("profileId") ?: 0L
            TriggerSetupScreen(
                repository = app.repository,
                profileId = profileId,
                onDone = { navController.popBackStack() }
            )
        }
        composable(Screen.Permissions.route) {
            PermissionsScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Settings.route) {
            SettingsScreen(repository = app.repository, onBack = { navController.popBackStack() })
        }
        composable(Screen.History.route) {
            HistoryScreen(repository = app.repository, onBack = { navController.popBackStack() })
        }
    }
}
