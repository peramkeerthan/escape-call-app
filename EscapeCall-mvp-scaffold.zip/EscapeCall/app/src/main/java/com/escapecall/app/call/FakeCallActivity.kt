package com.escapecall.app.call

import android.app.NotificationManager
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import com.escapecall.app.EscapeCallApp
import com.escapecall.app.data.CallHistoryEntry
import com.escapecall.app.data.CallProfile
import com.escapecall.app.data.CallType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FakeCallActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PROFILE_ID = "extra_profile_id"
    }

    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as EscapeCallApp
        val profileId = intent.getLongExtra(EXTRA_PROFILE_ID, -1L)

        setContent {
            var profile by remember { mutableStateOf<CallProfile?>(null) }
            var stage by remember { mutableStateOf(CallStage.RINGING) }
            var elapsedSeconds by remember { mutableStateOf(0) }

            LaunchedEffect(profileId) {
                profile = app.repository.getProfile(profileId)
                profile?.let { startRingingFeedback(it) }
            }

            LaunchedEffect(stage) {
                if (stage == CallStage.CONNECTED) {
                    stopRingingFeedback()
                    while (true) {
                        delay(1000)
                        elapsedSeconds += 1
                    }
                }
            }

            profile?.let { p ->
                FakeCallScreen(
                    profile = p,
                    stage = stage,
                    elapsedSeconds = elapsedSeconds,
                    onAnswer = { stage = CallStage.CONNECTED },
                    onReject = { endCall(p, elapsedSeconds = 0) },
                    onEndCall = { endCall(p, elapsedSeconds) }
                )
            }
        }
    }

    private fun startRingingFeedback(profile: CallProfile) {
        val ringtoneUri: Uri = profile.ringtoneUri?.let(Uri::parse)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ringtone = RingtoneManager.getRingtone(this, ringtoneUri)?.apply { play() }

        if (profile.vibrationEnabled) {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 800, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    private fun stopRingingFeedback() {
        ringtone?.stop()
        vibrator?.cancel()
    }

    private fun endCall(profile: CallProfile, elapsedSeconds: Int) {
        stopRingingFeedback()
        val app = application as EscapeCallApp
        lifecycleScope.launch {
            app.repository.logHistory(
                CallHistoryEntry(
                    timestampMillis = System.currentTimeMillis(),
                    profileName = profile.profileName,
                    triggerLabel = "configured trigger", // resolved from active trigger config in full impl
                    callType = CallType.FAKE,
                    durationMillis = elapsedSeconds * 1000L
                )
            )
        }
        getSystemService(NotificationManager::class.java)
            .cancel(FakeCallService.INCOMING_CALL_NOTIF_ID)
        finish()
    }

    override fun onDestroy() {
        stopRingingFeedback()
        super.onDestroy()
    }
}

enum class CallStage { RINGING, CONNECTED }

@Composable
private fun FakeCallScreen(
    profile: CallProfile,
    stage: CallStage,
    elapsedSeconds: Int,
    onAnswer: () -> Unit,
    onReject: () -> Unit,
    onEndCall: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(64.dp))

            if (profile.callerPhotoUri != null) {
                AsyncImage(
                    model = profile.callerPhotoUri,
                    contentDescription = null,
                    modifier = Modifier.size(140.dp).clip(CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier.size(140.dp).clip(CircleShape).background(Color(0xFF3A3A3A)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(profile.callerDisplayName.take(1).uppercase(), fontSize = 48.sp, color = Color.White)
                }
            }

            Spacer(Modifier.height(24.dp))
            Text(profile.callerDisplayName, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Text(
                text = if (stage == CallStage.RINGING) "Incoming call" else formatDuration(elapsedSeconds),
                color = Color(0xFFBBBBBB),
                fontSize = 16.sp
            )

            Spacer(Modifier.weight(1f))

            when (stage) {
                CallStage.RINGING -> Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 48.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    CallActionButton(icon = Icons.Filled.CallEnd, background = Color(0xFFE53935), label = "Decline", onClick = onReject)
                    CallActionButton(icon = Icons.Filled.Call, background = Color(0xFF43A047), label = "Answer", onClick = onAnswer)
                }
                CallStage.CONNECTED -> Box(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CallActionButton(icon = Icons.Filled.CallEnd, background = Color(0xFFE53935), label = "End", onClick = onEndCall)
                }
            }
        }
    }
}

@Composable
private fun CallActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, background: Color, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = onClick,
            modifier = Modifier.size(72.dp),
            colors = IconButtonDefaults.filledIconButtonColors(containerColor = background)
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

private fun formatDuration(totalSeconds: Int): String {
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return "%d:%02d".format(m, s)
}
