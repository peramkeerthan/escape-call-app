package com.escapecall.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.escapecall.app.data.CallProfile
import com.escapecall.app.data.CallType
import com.escapecall.app.data.ProfileRepository
import com.escapecall.app.trigger.ButtonEvent
import com.escapecall.app.trigger.TriggerConfig
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

private val defaultTrigger = TriggerConfig.ButtonSequence(
    sequence = listOf(ButtonEvent.VOLUME_DOWN, ButtonEvent.VOLUME_UP, ButtonEvent.VOLUME_DOWN)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditScreen(
    repository: ProfileRepository,
    profileId: Long,
    onOpenTriggerSetup: () -> Unit,
    onDone: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var loaded by remember { mutableStateOf(false) }

    var profileName by remember { mutableStateOf("") }
    var callerName by remember { mutableStateOf("") }
    var callerPhotoUri by remember { mutableStateOf<String?>(null) }
    var vibration by remember { mutableStateOf(true) }
    var delaySeconds by remember { mutableStateOf(10f) }
    var triggerConfig by remember { mutableStateOf(defaultTrigger) }
    // Real Call Mode toggle exists in the model (Section 5) but is disabled in the MVP UI (Section 16).

    LaunchedEffect(profileId) {
        if (profileId != 0L) {
            repository.getProfile(profileId)?.let { p ->
                profileName = p.profileName
                callerName = p.callerDisplayName
                callerPhotoUri = p.callerPhotoUri
                vibration = p.vibrationEnabled
                delaySeconds = (p.delayMillis / 1000L).toFloat()
                triggerConfig = Json.decodeFromString(p.triggerConfigJson)
            }
        }
        loaded = true
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { callerPhotoUri = it.toString() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (profileId == 0L) "New Profile" else "Edit Profile") },
                navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        if (!loaded) return@Scaffold

        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()
        ) {
            Box(
                modifier = Modifier.size(96.dp).align(Alignment.CenterHorizontally),
                contentAlignment = Alignment.Center
            ) {
                if (callerPhotoUri != null) {
                    AsyncImage(model = callerPhotoUri, contentDescription = null, modifier = Modifier.fillMaxSize())
                } else {
                    IconButton(onClick = { photoPicker.launch("image/*") }) {
                        Icon(Icons.Filled.Person, contentDescription = "Choose photo", modifier = Modifier.size(64.dp))
                    }
                }
            }
            TextButton(
                onClick = { photoPicker.launch("image/*") },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) { Text(if (callerPhotoUri == null) "Choose caller photo" else "Change photo") }

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = profileName,
                onValueChange = { profileName = it },
                label = { Text("Profile name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = callerName,
                onValueChange = { callerName = it },
                label = { Text("Caller display name") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Vibration")
                Switch(checked = vibration, onCheckedChange = { vibration = it })
            }

            Spacer(Modifier.height(12.dp))
            Text("Delay before ringing: ${delaySeconds.toInt()}s")
            Slider(
                value = delaySeconds,
                onValueChange = { delaySeconds = it },
                valueRange = 0f..60f,
                steps = 11
            )

            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onOpenTriggerSetup, modifier = Modifier.fillMaxWidth()) {
                Text("Configure trigger →")
            }

            Spacer(Modifier.weight(1f))

            Button(
                enabled = profileName.isNotBlank() && callerName.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    scope.launch {
                        repository.saveProfile(
                            CallProfile(
                                id = profileId,
                                profileName = profileName,
                                callerDisplayName = callerName,
                                callerPhotoUri = callerPhotoUri,
                                vibrationEnabled = vibration,
                                callType = CallType.FAKE, // Real Call Mode excluded from MVP (Section 16)
                                delayMillis = (delaySeconds * 1000).toLong(),
                                triggerConfigJson = Json.encodeToString(TriggerConfig.ButtonSequence.serializer(), triggerConfig),
                                isEnabled = true
                            )
                        )
                        onDone()
                    }
                }
            ) { Text("Save profile") }
        }
    }
}
