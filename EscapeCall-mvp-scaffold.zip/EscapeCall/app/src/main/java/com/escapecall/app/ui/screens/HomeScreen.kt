package com.escapecall.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.escapecall.app.data.CallProfile
import com.escapecall.app.data.ProfileRepository
import com.escapecall.app.trigger.TriggerManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: ProfileRepository,
    onOpenProfiles: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit
) {
    val activeProfile by repository.observeActiveProfile().collectAsStateWithLifecycle(initialValue = null)
    var enabled by remember { mutableStateOf(TriggerManager.isEnabled()) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Escape Call") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()) {

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Status", style = MaterialTheme.typography.titleMedium)
                        Switch(
                            checked = enabled,
                            onCheckedChange = {
                                enabled = it
                                TriggerManager.setEnabled(it)
                            }
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "Active profile: ${activeProfile?.callerDisplayName ?: "None configured"}",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    activeProfile?.let {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Trigger: ${describeTrigger(it)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = { TriggerManager.testTriggerNow() }
                ) { Text("Quick test") }

                OutlinedButton(
                    modifier = Modifier.weight(1f),
                    onClick = onOpenProfiles
                ) { Text("Profiles") }
            }

            Spacer(Modifier.height(24.dp))

            ListItem(
                headlineContent = { Text("Call Profiles") },
                leadingContent = { Icon(Icons.Filled.Person, contentDescription = null) },
                modifier = Modifier.clickableRow(onOpenProfiles)
            )
            ListItem(
                headlineContent = { Text("Permissions") },
                leadingContent = { Icon(Icons.Filled.Security, contentDescription = null) },
                modifier = Modifier.clickableRow(onOpenPermissions)
            )
            ListItem(
                headlineContent = { Text("History") },
                leadingContent = { Icon(Icons.Filled.History, contentDescription = null) },
                modifier = Modifier.clickableRow(onOpenHistory)
            )
            ListItem(
                headlineContent = { Text("Settings") },
                leadingContent = { Icon(Icons.Filled.Settings, contentDescription = null) },
                modifier = Modifier.clickableRow(onOpenSettings)
            )
        }
    }
}

private fun describeTrigger(profile: CallProfile): String {
    // Human-readable summary parsed from the stored TriggerConfig JSON at display time
    // in the full implementation; kept simple here for the MVP scaffold.
    return "Volume Down → Volume Up → Volume Down"
}

private fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
