package com.escapecall.app.domain

import android.content.Context
import android.content.Intent
import com.escapecall.app.call.FakeCallService

/**
 * Section 22's Action Engine: the thing a trigger fires INTO. Fake Call is the only
 * implementation in the MVP. Real Call / Notification / Alarm are future ActionEngine
 * implementations — TriggerManager never needs to change to support them.
 */
interface ActionEngine {
    fun onTriggerFired()
}

class FakeCallActionEngine(private val context: Context) : ActionEngine {
    override fun onTriggerFired() {
        val intent = Intent(context, FakeCallService::class.java).apply {
            action = FakeCallService.ACTION_START_FAKE_CALL
        }
        context.startForegroundService(intent)
    }
}

// Not implemented in MVP; kept here to show where Real Call plugs in per Section 7 (v2).
class RealCallActionEngine(private val context: Context) : ActionEngine {
    override fun onTriggerFired() {
        throw UnsupportedOperationException(
            "Real Call Mode is out of MVP scope (Section 16). " +
            "Implementation must request CALL_PHONE and use Intent(Intent.ACTION_CALL) only " +
            "after explicit user confirmation — never silently."
        )
    }
}
