package com.escapecall.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CallType { FAKE, REAL } // REAL is modeled now but disabled in UI for the MVP (Section 16/7).

@Entity(tableName = "call_profiles")
data class CallProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileName: String,
    val callerDisplayName: String,
    /** Local file URI only — never uploaded anywhere (Section 14). */
    val callerPhotoUri: String? = null,
    val ringtoneUri: String? = null,
    val vibrationEnabled: Boolean = true,
    val callType: CallType = CallType.FAKE,
    val phoneNumberForRealCall: String? = null, // only used if callType == REAL
    val delayMillis: Long = 10_000L,
    val triggerConfigJson: String, // serialized TriggerConfig, see trigger/TriggerConfig.kt
    val isActive: Boolean = false,
    val isEnabled: Boolean = true
)

@Entity(tableName = "call_history")
data class CallHistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long,
    val profileName: String,
    val triggerLabel: String,
    val callType: CallType,
    val durationMillis: Long
)
