package com.escapecall.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CallProfileDao {
    @Query("SELECT * FROM call_profiles ORDER BY id DESC")
    fun observeAll(): Flow<List<CallProfile>>

    @Query("SELECT * FROM call_profiles WHERE isActive = 1 LIMIT 1")
    fun observeActive(): Flow<CallProfile?>

    @Query("SELECT * FROM call_profiles WHERE id = :id")
    suspend fun getById(id: Long): CallProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: CallProfile): Long

    @Delete
    suspend fun delete(profile: CallProfile)

    @Query("UPDATE call_profiles SET isActive = 0")
    suspend fun clearActive()

    @Transaction
    suspend fun setActive(id: Long) {
        clearActive()
        markActive(id)
    }

    @Query("UPDATE call_profiles SET isActive = 1 WHERE id = :id")
    suspend fun markActive(id: Long)
}

@Dao
interface CallHistoryDao {
    @Query("SELECT * FROM call_history ORDER BY timestampMillis DESC")
    fun observeAll(): Flow<List<CallHistoryEntry>>

    @Insert
    suspend fun insert(entry: CallHistoryEntry)

    @Query("DELETE FROM call_history")
    suspend fun clearAll()
}
