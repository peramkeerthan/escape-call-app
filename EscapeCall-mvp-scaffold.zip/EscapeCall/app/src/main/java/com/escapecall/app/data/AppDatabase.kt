package com.escapecall.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [CallProfile::class, CallHistoryEntry::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun callProfileDao(): CallProfileDao
    abstract fun callHistoryDao(): CallHistoryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "escapecall.db" // local-only, unencrypted-at-rest by default; Section 15 note below.
                    // NOTE: for phone numbers in Real Call Mode (v2), wrap this with SQLCipher or
                    // store the number in EncryptedSharedPreferences/Keystore instead of a plain column.
                ).build().also { INSTANCE = it }
            }
    }
}

/** Thin repository so ViewModels never touch DAOs directly. */
class ProfileRepository(private val db: AppDatabase) {
    fun observeProfiles() = db.callProfileDao().observeAll()
    fun observeActiveProfile() = db.callProfileDao().observeActive()
    suspend fun getProfile(id: Long) = db.callProfileDao().getById(id)
    suspend fun saveProfile(profile: CallProfile) = db.callProfileDao().upsert(profile)
    suspend fun deleteProfile(profile: CallProfile) = db.callProfileDao().delete(profile)
    suspend fun setActive(id: Long) = db.callProfileDao().setActive(id)

    fun observeHistory() = db.callHistoryDao().observeAll()
    suspend fun logHistory(entry: CallHistoryEntry) = db.callHistoryDao().insert(entry)
    suspend fun clearHistory() = db.callHistoryDao().clearAll()
}
