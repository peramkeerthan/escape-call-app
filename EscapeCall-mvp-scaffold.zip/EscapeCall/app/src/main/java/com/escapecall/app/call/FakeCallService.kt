package com.escapecall.app.call

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.escapecall.app.EscapeCallApp
import com.escapecall.app.R
import com.escapecall.app.data.CallProfile
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * Owns the countdown between "trigger fired" and "phone starts ringing" (Section 8), and the
 * notification lifecycle. Runs as a foreground service so Android doesn't kill it mid-countdown.
 *
 * Full-screen call UI strategy (Section 13 caveat): setFullScreenIntent() is requested, but on
 * some OEM builds / Android 14+ configurations the system may downgrade this to a heads-up
 * notification instead of launching FakeCallActivity automatically. We do not attempt to defeat
 * that — the notification's tap target still opens the same call UI, which is the documented
 * fallback the spec asks for in Section 7 ("closest compliant experience").
 */
class FakeCallService : Service() {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var countdownJob: Job? = null

    companion object {
        const val ACTION_START_FAKE_CALL = "com.escapecall.app.action.START_FAKE_CALL"
        const val ACTION_CANCEL = "com.escapecall.app.action.CANCEL"
        private const val COUNTDOWN_CHANNEL = "countdown_channel"
        private const val COUNTDOWN_NOTIF_ID = 1001
        const val INCOMING_CALL_NOTIF_ID = 1002
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                countdownJob?.cancel()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_START_FAKE_CALL -> startCountdownThenRing()
        }
        return START_NOT_STICKY
    }

    private fun startCountdownThenRing() {
        val app = application as EscapeCallApp
        countdownJob?.cancel()
        countdownJob = scope.launch {
            val profile = app.repository.observeActiveProfile().first()
                ?: return@launch // no active profile configured; nothing to do

            startForeground(COUNTDOWN_NOTIF_ID, buildCountdownNotification())

            delay(profile.delayMillis) // Section 8: configurable delay

            showIncomingCallNotification(profile)
            stopForeground(STOP_FOREGROUND_DETACH) // hand off to the persistent call notification
        }
    }

    private fun buildCountdownNotification(): Notification =
        NotificationCompat.Builder(this, COUNTDOWN_CHANNEL)
            .setContentTitle(getString(R.string.countdown_notification_title))
            .setSmallIcon(R.drawable.ic_call_placeholder)
            .setPriority(NotificationCompat.PRIORITY_LOW) // subtle, per Section 8's "configurable subtle indication"
            .setOngoing(true)
            .build()

    private fun showIncomingCallNotification(profile: CallProfile) {
        val fullScreenIntent = Intent(this, FakeCallActivity::class.java).apply {
            putExtra(FakeCallActivity.EXTRA_PROFILE_ID, profile.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this, 0, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, incomingCallChannelId())
            .setContentTitle(profile.callerDisplayName)
            .setContentText(getString(R.string.incoming_call_label))
            .setSmallIcon(R.drawable.ic_call_placeholder)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent) // fallback tap target if full-screen is suppressed
            .setOngoing(true)
            .setAutoCancel(false)
            .build()

        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(INCOMING_CALL_NOTIF_ID, notification)
    }

    private fun incomingCallChannelId(): String {
        val id = "incoming_call_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(id, getString(R.string.incoming_call_channel_name), NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null) // ringtone is played manually so we can support "test" mode and stop it precisely
                enableVibration(false) // vibration also handled manually to match the profile's setting
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return id
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val countdown = NotificationChannel(
                COUNTDOWN_CHANNEL, getString(R.string.countdown_channel_name), NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(countdown)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        countdownJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
