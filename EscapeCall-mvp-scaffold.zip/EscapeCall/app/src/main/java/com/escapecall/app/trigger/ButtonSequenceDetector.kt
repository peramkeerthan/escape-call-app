package com.escapecall.app.trigger

import android.view.KeyEvent

/**
 * Implements Section 9 (Accidental Trigger Protection):
 *  - exact button order required
 *  - max interval between presses
 *  - whole-sequence activation timeout
 *  - cooldown after a successful activation (owned by caller, see TriggerManager)
 *
 * Only reacts to key DOWN events to avoid double counting a single press.
 */
class ButtonSequenceDetector(private val config: TriggerConfig.ButtonSequence) : TriggerDetector {

    private var progress = 0
    private var sequenceStartTime = 0L
    private var lastEventTime = 0L

    override fun onKeyEvent(keyCode: Int, isDown: Boolean, eventTimeMillis: Long): Boolean {
        if (!isDown) return false
        val event = keyCode.toButtonEvent() ?: return false

        val expected = config.sequence.getOrNull(progress) ?: run { reset(); return false }

        val withinInterval = progress == 0 ||
            (eventTimeMillis - lastEventTime) <= config.maxIntervalMillis
        val withinTotalTimeout = progress == 0 ||
            (eventTimeMillis - sequenceStartTime) <= config.activationTimeoutMillis

        if (event != expected || !withinInterval || !withinTotalTimeout) {
            // Wrong button or too slow: reset, but allow this same press to start a fresh sequence
            // if it happens to match step 0 (so "VolDown VolUp VolUp VolDown VolUp VolDown" doesn't
            // dead-end just because of a leading stray press).
            reset()
            if (event == config.sequence.first()) {
                progress = 1
                sequenceStartTime = eventTimeMillis
                lastEventTime = eventTimeMillis
            }
            return false
        }

        if (progress == 0) sequenceStartTime = eventTimeMillis
        lastEventTime = eventTimeMillis
        progress += 1

        return if (progress >= config.sequence.size) {
            reset()
            true
        } else {
            false
        }
    }

    override fun reset() {
        progress = 0
        sequenceStartTime = 0L
        lastEventTime = 0L
    }

    private fun Int.toButtonEvent(): ButtonEvent? = when (this) {
        KeyEvent.KEYCODE_VOLUME_UP -> ButtonEvent.VOLUME_UP
        KeyEvent.KEYCODE_VOLUME_DOWN -> ButtonEvent.VOLUME_DOWN
        else -> null
    }
}
