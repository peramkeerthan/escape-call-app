package com.escapecall.app.trigger

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Android does NOT let an app silently re-enable an AccessibilityService after reboot —
 * that has to stay a deliberate user action for good reason. This receiver only restores
 * TriggerManager's in-memory config so that once the user (or the OS, if already granted)
 * reactivates the accessibility service, detection resumes without the user re-entering
 * profile settings. It does not attempt to bypass the accessibility re-grant requirement.
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // No-op beyond letting the app know a reboot happened; MainActivity/App.onCreate
            // reloads the active profile from Room on next launch or accessibility reconnect.
        }
    }
}
