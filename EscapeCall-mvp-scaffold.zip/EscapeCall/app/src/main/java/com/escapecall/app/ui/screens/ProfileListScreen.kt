package com.escapecall.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.escapecall.app.data.CallProfile
import com.escapecall.app.data.ProfileRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileListScreen(
    repository: ProfileRepository,
    onCreateProfile: () -> Unit,
    onEditProfile: (Long) -> Unit,
    onBack: () -> Unit
) {
    val profiles by repository.observeProfiles().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Call Profiles") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreateProfile) { Icon(Icons.Filled.Add, contentDescription = "Create profile") }
        }
    ) { padding ->
        if (profiles.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("No profiles yet. Tap + to create one.")
            }
        } else {
            LazyColumnProfiles(
                profiles = profiles,
                padding = padding,
                onEdit = onEditProfile,
                onSetActive = { id -> scope.launch { repository.setActive(id) } },
                onDuplicate = { p -> scope.launch { repository.saveProfile(p.copy(id = 0, profileName = "${p.profileName} copy", isActive = false)) } },
                onDelete = { p -> scope.launch { repository.deleteProfile(p) } }
            )
        }
    }
}

@Composable
private fun LazyColumnProfiles(
    profiles: List<CallProfile>,
    padding: PaddingValues,
    onEdit: (Long) -> Unit,
    onSetActive: (Long) -> Unit,
    onDuplicate: (CallProfile) -> Unit,
    onDelete: (CallProfile) -> Unit
) {
    LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
        items(items = profiles, key = { it.id }) { profile ->
            ListItem(
                headlineContent = { Text(profile.profileName) },
                supportingContent = { Text("Caller: ${profile.callerDisplayName} · ${profile.callType}") },
                leadingContent = {
                    RadioButton(selected = profile.isActive, onClick = { onSetActive(profile.id) })
                },
                trailingContent = {
                    Row {
                        IconButton(onClick = { onDuplicate(profile) }) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "Duplicate")
                        }
                        IconButton(onClick = { onDelete(profile) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete")
                        }
                    }
                },
                modifier = Modifier.clickable { onEdit(profile.id) }
            )
            Divider()
        }
    }
}

