package com.escapecall.app

import android.app.Application
import com.escapecall.app.data.AppDatabase
import com.escapecall.app.data.ProfileRepository
import com.escapecall.app.domain.ActionEngine
import com.escapecall.app.trigger.TriggerConfig
import com.escapecall.app.trigger.TriggerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class EscapeCallApp : Application() {

    lateinit var repository: ProfileRepository
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        repository = ProfileRepository(AppDatabase.get(this))
    }

    /** Called when the accessibility service (re)connects, so TriggerManager always reflects
     *  whichever profile is currently marked active. */
    fun reconfigureTriggerManagerFromActiveProfile(engine: ActionEngine) {
        appScope.launch {
            val active = repository.observeActiveProfile().first() ?: return@launch
            if (!active.isEnabled) {
                TriggerManager.setEnabled(false)
                return@launch
            }
            val config = Json.decodeFromString<TriggerConfig.ButtonSequence>(active.triggerConfigJson)
            TriggerManager.configure(config, engine)
            TriggerManager.setEnabled(true)
        }
    }
}
