package com.escapecall.app.trigger

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.escapecall.app.EscapeCallApp
import com.escapecall.app.domain.FakeCallActionEngine

/**
 * This is the load-bearing piece Section 13 asks us to validate up front: a plain foreground-only
 * key listener cannot see volume presses once the screen locks or another app is in front. An
 * AccessibilityService with flagRequestFilterKeyEvents CAN, and it's the officially supported
 * mechanism for it (as opposed to any private/undocumented API).
 *
 * Trade-off to disclose to the user on the Permissions screen: enabling an accessibility service
 * is a strong permission grant in Android's UI, and this screen must be honest that we only use it
 * for key events (see trigger_accessibility_service_config.xml — no window content access).
 */
class TriggerAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        val app = application as EscapeCallApp
        // Wire the manager to the current active profile's trigger + the fake-call action.
        app.reconfigureTriggerManagerFromActiveProfile(FakeCallActionEngine(applicationContext))
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        TriggerManager.onKeyEvent(
            keyCode = event.keyCode,
            isDown = event.action == KeyEvent.ACTION_DOWN,
            eventTimeMillis = event.eventTime
        )
        // Return false: never consume the event, so normal volume behavior (actually changing
        // volume) still works. This trigger must not interfere with regular phone use (Section 21).
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Unused: this service only cares about key events, not window/content events.
    }

    override fun onInterrupt() {}
}
