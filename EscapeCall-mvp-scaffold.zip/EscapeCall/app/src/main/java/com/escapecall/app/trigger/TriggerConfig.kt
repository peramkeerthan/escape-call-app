package com.escapecall.app.trigger

import kotlinx.serialization.Serializable

/**
 * Trigger architecture (Section 4 & 22): TriggerType is an open set. The MVP implements only
 * BUTTON_SEQUENCE. Adding GESTURE, SCREEN_TAP, BLUETOOTH, NFC, SCHEDULE, VOICE, WIDGET, TILE
 * later means adding a new sealed subtype + a new Detector — nothing else in the pipeline changes.
 */
@Serializable
sealed class TriggerConfig {

    abstract val id: String

    @Serializable
    data class ButtonSequence(
        override val id: String = "button_sequence",
        /** e.g. [VOLUME_DOWN, VOLUME_UP, VOLUME_DOWN] */
        val sequence: List<ButtonEvent>,
        val maxIntervalMillis: Long = 2500L, // Section 9: max time between presses
        val activationTimeoutMillis: Long = 4000L, // whole-sequence timeout
        val cooldownMillis: Long = 3000L // Section 9: cooldown after activation
    ) : TriggerConfig()

    // Placeholders so the UI/domain layer can already branch on future types without
    // needing a rewrite when they're implemented (Section 4D).
    @Serializable
    data class Gesture(override val id: String = "gesture", val notYetImplemented: Boolean = true) : TriggerConfig()

    @Serializable
    data class ScreenTap(override val id: String = "screen_tap", val notYetImplemented: Boolean = true) : TriggerConfig()
}

enum class ButtonEvent { VOLUME_UP, VOLUME_DOWN, VOLUME_UP_LONG, VOLUME_DOWN_LONG }

/** Every detector implements this. TriggerManager only knows this interface. */
interface TriggerDetector {
    /** Feed a raw platform key code + action; returns true if this completed the configured sequence. */
    fun onKeyEvent(keyCode: Int, isDown: Boolean, eventTimeMillis: Long): Boolean
    fun reset()
}
