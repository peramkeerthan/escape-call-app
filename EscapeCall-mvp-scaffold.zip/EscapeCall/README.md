# Escape Call — MVP

A discreet, user-configured trigger that produces a controlled incoming-call experience
(the "excuse call" pattern). This repo implements the MVP scope defined in Section 16 of the
spec: **one button-sequence trigger + fake call only.**

## 1. Platform research (Section 23, steps 1–4)

| Question | Finding | Design consequence |
|---|---|---|
| Can a plain `Activity`/foreground `Service` see volume-key presses while the app is backgrounded or the screen is locked? | No. Android only routes `KeyEvent`s to the currently focused window. | Used an `AccessibilityService` with `flagRequestFilterKeyEvents` — the documented, supported mechanism for observing hardware keys system-wide. User must explicitly enable it once in Settings → Accessibility; the app cannot silently turn this on. |
| Does enabling that service let the app read the screen? | Only if we also request content/window event types. We deliberately request **only** `typeWindowStateChanged` + key-event filtering — no `typeViewClicked`, no `TYPE_WINDOW_CONTENT_CHANGED`. | Keeps the permission honest and narrow; documented in `trigger_accessibility_service_config.xml` and surfaced in plain language on the Permissions screen. |
| Can the fake call reliably show over the lock screen? | `showWhenLocked` + `turnScreenOn` on the activity, plus `setFullScreenIntent()` on the notification, is the supported path — but Android 14+ and some OEM skins may downgrade an unprivileged app's full-screen intent to a heads-up notification instead of auto-launching. | Built the fallback in from day one: the notification's tap target opens the same `FakeCallActivity`, so the worst case is "tap the notification" instead of "screen lights up automatically." No attempt to defeat the OS restriction. |
| What permissions does the MVP actually need? | `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE` (+ `FOREGROUND_SERVICE_SPECIAL_USE`), `VIBRATE`, `USE_FULL_SCREEN_INTENT`, `BIND_ACCESSIBILITY_SERVICE` (declared on the service, not requested from the user directly), `RECEIVE_BOOT_COMPLETED`. | `CALL_PHONE` (Real Call Mode) is **not** in the manifest — it isn't needed until Real Call Mode ships, per "only request permissions that are actually necessary" (Section 10). |
| Is silent, automatic outbound calling possible/appropriate? | No — and it shouldn't be. `ACTION_CALL` requires `CALL_PHONE` and always requires explicit user setup beforehand; there's no way to make an outbound call look inbound. | Real Call Mode is scoped out of the MVP (Section 16) and the `RealCallActionEngine` stub throws until implemented, so it can't be accidentally wired up. |
| Reboot behavior | Android intentionally does **not** allow silently re-enabling an `AccessibilityService` after reboot — that has to stay a deliberate user action. | `BootCompletedReceiver` only restores in-memory trigger config; it does not attempt to re-grant the accessibility permission itself. |

## 2. Architecture (Section 12/22)

```
UI (Compose) → ViewModel-less state hoisting in screens (MVP-sized; promote to real ViewModels as it grows)
                    ↓
        ProfileRepository (Room: profiles + history)
                    ↓
        TriggerManager  ←── TriggerAccessibilityService (raw KeyEvents)
                    ↓
             ActionEngine  (interface)
              ├── FakeCallActionEngine  [implemented]
              └── RealCallActionEngine [stub, v2]
                    ↓
        FakeCallService (delay countdown, notification/full-screen-intent)
                    ↓
        FakeCallActivity (ringing UI → connected UI, Section 6)
```

`TriggerManager` and the detectors (`ButtonSequenceDetector`) know nothing about calls.
`ActionEngine` is the seam described in Section 22 — adding Gesture/ScreenTap triggers, or a
Notification/Alarm action, means adding a new class on either side of that seam without touching
the other.

## 3. What's implemented (MVP, Section 16)

- Button-sequence trigger (order, max interval between presses, activation timeout, cooldown) —
  `trigger/ButtonSequenceDetector.kt`, accidental-activation protections from Section 9.
- Fake call: ringing screen → answer/reject → connected screen with duration → end call
  (`call/FakeCallActivity.kt`), full-screen-intent notification with a tap fallback
  (`call/FakeCallService.kt`).
- Profiles: name, caller name/photo, ringtone, vibration, delay, per-profile trigger, active/enabled
  flags; create/edit/duplicate/delete/select-active (`data/`, `ui/screens/ProfileListScreen.kt`,
  `ProfileEditScreen.kt`).
- Trigger setup screen with test affordance and sensitivity/timing sliders.
- Permissions screen explaining each request in plain language before sending the user to system
  settings (Section 10/14).
- Local-only Room storage for profiles + history; no analytics, no network calls anywhere in the app.
- Settings + History screens (Section 10/11).

## 4. Explicitly NOT in this build (Section 16/17)

- Real Call Mode (Section 7) — model support exists (`CallType.REAL`, `RealCallActionEngine` stub)
  but is disabled in the UI until it's implemented and tested against current Android APIs, per
  Section 23 step 11.
- Gesture / screen-tap / Bluetooth / NFC / scheduled / voice / widget / quick-settings-tile triggers
  (Section 4D) — the `TriggerConfig` sealed class and `TriggerDetector` interface are ready for them.
- Simulated conversation prompts, trusted-contact remote trigger (Section 18) — v3 ideas.

## 5. Building

Requires Android Studio (Koala+) or a matching command-line toolchain, JDK 17, Android SDK 35.

```bash
./gradlew assembleDebug
```

There's no CI runner in this sandbox and no attached Android device/emulator, so **this has not
been run or tested on an actual device** — per Section 23's closing instruction ("do not claim a
feature works until it has been tested on an actual Android device"), treat this as an unverified
scaffold, not a finished, tested app. Before relying on it:

1. Install to a real device, enable the accessibility service from the Permissions screen.
2. Create a profile, set its trigger, background the app, lock the screen, perform the sequence.
3. Confirm the fake call appears and that the trigger does not interfere with normal volume use.
4. Work through the Section 21 test matrix (DND, battery saver, silent mode, real incoming call
   during a fake one, force-stop, reboot, OEM-specific background restrictions) before shipping.

## 6. Known gaps to close before this is production-ready

- Ringtone picker (`RingtoneManager.ACTION_RINGTONE_PICKER`) isn't wired into
  `ProfileEditScreen` yet — it currently falls back to the device default.
- `HomeScreen.describeTrigger()` is a placeholder string; it should decode the stored
  `TriggerConfig` JSON and render the actual configured sequence.
- No `ViewModel`/`SavedStateHandle` layer yet — screens hold state directly, which is fine at this
  size but should be refactored if more screens are added.
- Caller photo `Uri` permissions: `ActivityResultContracts.GetContent()` gives a transient read
  grant; for photos to survive app restarts reliably, take a persistable URI permission or copy
  the image into app-private storage.
